/*
 *  Copyright (C) 2012 Khaldoon Ghanem
 *  See the file license.txt for copying permission.
 */
 
 Description:
 ============
 This application visualizes complex functions of a single complex varaible using the domain coloring method. It is implemented on the fragment shader. 
 
 Compliation:
 ============
- The program is written in c99. It should compile and work on Linux, Mac OS X and Windows (using MinGW).

- For Linux and Mac, the following should be installed: Glut library, Glew library, lex tool, yacc tool. 
- For windows, nothing is needed as they are already included in directory 'Win32'.
- For running the program, the computer should have a GPU with a driver that support GLSL version 1.2 at least.
- Known Issues: On windows, scroll button doesn't work. It is a problem of Glut library on windows.

Program Usage:
==============
- The program reads input from 'stdin' line by line.
- Each line specifies a complex function to be rendered.
- If you use keyboard for input, remember to end the input by pressing 'Ctrl+D'.
- Input can be redirected from other sources using command line redircting operators '|' '<'.
- As an example, you can use the following to read functions from file 'misc.data': ./res/coloring.exe < ./res/misc.data
- An interesting usage of the program is using it to see how the tylor series conveges to their corresponding function as you add more and more terms. The file exp_tylor.data lists tylor series for the exponentail function up to 20 terms.

How To Express Complex Functions:
------------------------------------
- Number are specified using decimal notation only.
- Letters 'z' and 'Z' are used for the complex variable.
- Letter 'i' can be prepended to any number to make it imaginary. e.g. 5i, -3.5i, i, 0.04i.
- Operators '+' '-' '/' '*' have the same meaning, associativity, and precedence as in the c/c++ language.
- Operator '^' is the raising power operator, left associative and has the highest precedence. Only integer(positive or negative) powers are allowed.
- A number can be prepended to the complex varialbe for multiplication e.g. -4.5z. Hint: This is faster than -4.5*z because the number in this case will be converted to a complex one first.
- Functions 'sin', 'cos', 'log', 'exp' can be used.

Keyboard Control:
------------------
W:	Up.
S:	Down.
A:	Left.
D:	Right.

Q:	Zoom out.
E:	Zoom in.

C:	Center screen to (0,0).
R:	Reset zoom to default.

Space:	Switch color map.

X:	Switch to next function.
Z:	Switch to previous function.

1..9:	Switch to input function number [1..9]
0:	Switch to original map i.e. f(z) = z.

P:	Print screen info.
F:	Full Screen.

Mouse Control:
--------------
Scroll:		Zoom in & out.
Left_Btn+Move:	Pan.
_________________________________________________
	
