function PPDemo(cs)

%PhasePlotDemo  Demonstration of various color schemes
%
% call without argument to see a demonstration of all color schemes
% call 'PhasePlotDemo(cs)' where cs is a color scheme 
% call 'help colscheme' to get a list of available color schemes 

% part of the PhasePlot package: demo of various color schemes
% Version 2.1, June 30, 2012

% Elias Wegert, TU Bergakademie Freiberg, 09596 Freiberg, Germany
% wegert@math.tu-freiberg.de

%% if there are memory problems reduce the resolution

xres = 800;
yres = 800;

%%

x = 2*linspace(-1,1,xres);
y = 2*linspace(-1,1,yres);

[x,y] = meshgrid(x,y);

z = x+1i*y;

figure(1);
clf
hold on

w = (z-1)./(z.*z+z+1);

if nargin == 1;
    PhasePlot(z,w,cs);
else
    
%% proper phase plot

PhasePlot(z,w,'p');
title('p - proper phase plot')
pause

%% colored modifications

PhasePlot(z,w,'m');
title('m - enhanced phase plot with modulus jumps')
pause

PhasePlot(z,w,'c');
title('c - phase plot with conformal polar grid')
pause

PhasePlot(z,w,'j',[1,-1,1i,-1i]);
title('j - phase plot with some enhanced isochromatic lines')
pause

PhasePlot(z,w,'q');
title('q - phase plot colored in steps ')
pause

PhasePlot(z,w,'d');
title('d - standard domain coloring')
pause

PhasePlot(z,w,'e');
title('e - enhanced domain coloring')
pause

%% black and white modifications

PhasePlot(z,w,'u');
title('u - polar chessboard')
pause

PhasePlot(z,w,'a');
title('a - alternating black and white phase')
pause

PhasePlot(z,w,'b');
title('b - alternating black and white modulus')
pause


%% color schemes based on cartesian coordinates

%w = sin(3*z);

PhasePlot(z,w,'v');
title('v - Cartesian chessboard')
pause

PhasePlot(z,w,'h');
title('x - alternating black and white real part')
pause

PhasePlot(z,w,'i');
title('y - alternating black and imaginary part')

end

