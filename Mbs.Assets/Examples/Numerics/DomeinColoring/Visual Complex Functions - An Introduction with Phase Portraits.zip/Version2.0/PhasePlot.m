function PP = PhasePlot(z,f,cs,pres,t,h)

%PhasePlot(z,f,cs)
%
% phase plot of complex function f(z)
%
% z - complex field of arguments
% f - complex field of values f(z)
% cs   (optional) -  color scheme
%
% call 'help colscheme' to see a list of available color schemes 
% call 'PPDemo' to see a demonstration of all color schemes 

% t    (optional) -  positions of jumps at unit circle
% pres (optional) -  number of jumps in phase
%
% h - handle to colored surface

% part of the PhasePlot package: generates enhanced phase plots 
% Version 2.1, June 30, 2012

% Elias Wegert, TU Bergakademie Freiberg, 09596 Freiberg, Germany
% wegert@math.tu-freiberg.de

if nargin==6
  PP = pltphase(z,f,cs,t,pres,h);
elseif nargin==5
  PP = pltphase(z,f,cs,t,pres);
elseif nargin==4
  if cs=='j'  
    PP = pltphase(z,f,cs,pres);
  else
    PP = pltphase(z,f,cs,[],pres);
  end
elseif nargin==3
  PP = pltphase(z,f,cs);
elseif nargin==2
  PP = pltphase(z,f);
else
  disp('PhasePlot(z,f) - phase plot of complex function f(z)')
  disp('  call as PhasePlot(z,f,colorscheme) for various coloring options');
  disp('  call PPDemo for a demonstration of the implemented color schemes');
end

