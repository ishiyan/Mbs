function h = pltphase(z,f,cs,t,pres,height)

%h = pltphase(z,f,cs,t,pres)
%
% phase plot of complex function f(z)
%
% z - complex field of arguments
% f - complex field of values f(z)
% cs   (optional) -  color scheme
% t    (optional) -  positions of jumps at unit circle
% pres (optional) -  number of jumps in phase

% h - handle to colored surface

% part of the PhasePlot package: generates phase plot of various types
% Version 2.1, June 30, 2012

% Elias Wegert, TU Bergakademie Freiberg, 09596 Freiberg, Germany
% wegert@math.tu-freiberg.de

if nargin<6, height=0; end

if nargin<5, pres=20; end

if nargin<4 || isempty(t), t=exp(1i*linspace(-pi,pi,pres+1)); t=t(1:pres); 
end

if nargin<3, cs = 'p'; end

pres=length(t);

RGB = colscheme(f,cs,t,pres); 

h = surf(real(z),imag(z),height*ones(size(z)),RGB);

set(h,'EdgeColor','none');

view(0,90)
axis equal
axis off


