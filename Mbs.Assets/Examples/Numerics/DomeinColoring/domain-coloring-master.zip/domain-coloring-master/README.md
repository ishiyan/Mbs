# Domain-coloring
Domain coloring in Rust

     sin(1/z) 

![img](./out0.png)

     sin((z - 1.) / (z + 1.)).powi(3)

![img](./out.png)

        ((z * z - 1.) * (z - 2. - Complex::i()).powi(2)) / (z * z + 2. + 2. * Complex::i())
![img](./pic.png)