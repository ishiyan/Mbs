library(testthat)
library(viscomplexr)

test_check("viscomplexr")
